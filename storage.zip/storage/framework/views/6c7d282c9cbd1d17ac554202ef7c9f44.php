

<?php $__env->startSection('title', 'Pesan Masuk & Rating'); ?>
<?php $__env->startSection('subtitle', 'Daftar pesan, ulasan, dan rating dari pengunjung website'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm rounded-4 p-4">

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr class="text-secondary small text-uppercase">
                    <th>Pengirim</th>
                    <th>Rating</th>
                    <th>Pesan Singkat</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="<?php echo e($contact->status == 'unread' ? 'fw-bold bg-light bg-opacity-50' : ''); ?>">
                        <td>
                            <div class="fw-bold text-dark"><?php echo e($contact->nama); ?></div>
                            <div class="text-muted small fw-normal"><?php echo e($contact->email); ?></div>
                        </td>

                        
                        <td>
                            <div class="text-warning small">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <?php if($i <= $contact->rating): ?>
                                        <i class="bi bi-star-fill"></i>
                                    <?php else: ?>
                                        <i class="bi bi-star text-muted opacity-25"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                <span class="ms-1 fw-bold text-dark small">(<?php echo e($contact->rating ?? 0); ?>/5)</span>
                            </div>
                        </td>

                        <td>
                            <p class="text-muted small mb-0" style="display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">
                                <?php echo e($contact->pesan); ?>

                            </p>
                        </td>

                        <td class="text-secondary small">
                            <i class="bi bi-clock me-1"></i><?php echo e($contact->created_at->translatedFormat('d M Y, H:i')); ?>

                        </td>

                        <td>
                            <?php if($contact->status == 'unread'): ?>
                                <span class="badge bg-warning text-dark">Belum Dibaca</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Sudah Dibaca</span>
                            <?php endif; ?>
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex gap-1">
                                <a href="<?php echo e(route('admin.kontak.show', $contact->id)); ?>" class="btn btn-sm btn-light border text-primary" title="Lihat Pesan">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <form action="<?php echo e(route('admin.kontak.destroy', $contact->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus pesan ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-light border text-danger" title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5">
                            <i class="bi bi-envelope-open fs-1 text-primary opacity-50"></i>
                            <h6 class="fw-bold mt-2">Belum Ada Pesan & Rating Masuk</h6>
                            <p class="text-muted small">Pesan dan ulasan pengunjung melalui form kontak akan muncul di sini.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($contacts->hasPages()): ?>
        <div class="d-flex justify-content-between align-items-center border-top pt-4 mt-3">
            <small class="text-muted">
                Menampilkan <?php echo e($contacts->firstItem()); ?> - <?php echo e($contacts->lastItem()); ?> dari <?php echo e($contacts->total()); ?> data
            </small>
            <?php echo e($contacts->links()); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>