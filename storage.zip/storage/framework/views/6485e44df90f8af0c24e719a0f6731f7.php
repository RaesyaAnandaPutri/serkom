<nav class="navbar navbar-expand-lg sticky-top border-bottom py-3" style="background: #fafafa;">
    <div class="container">

        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-dark text-decoration-none" href="<?php echo e(url('/')); ?>">
            
            <img src="<?php echo e(asset('images/logo solusi koneksi anda.png')); ?>" alt="Logo Solusi Koneksi Anda" style="width: 38px; height: 38px; object-fit: contain;" class="rounded-3">
            Solusi Koneksi Anda
        </a>

        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-lg-auto mt-3 mt-lg-0">
                <li class="nav-item">
                    <a class="nav-link small <?php echo e(request()->is('/') ? 'text-dark fw-bold' : 'text-secondary'); ?>" href="<?php echo e(url('/')); ?>">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link small <?php echo e(request()->is('profil-perusahaan*') ? 'text-dark fw-bold' : 'text-secondary'); ?>" href="<?php echo e(url('/profil-perusahaan')); ?>">Profil Perusahaan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link small <?php echo e(request()->is('layanan*') ? 'text-dark fw-bold' : 'text-secondary'); ?>" href="<?php echo e(url('/layanan')); ?>">Produk & Layanan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link small <?php echo e(request()->is('galeri*') ? 'text-dark fw-bold' : 'text-secondary'); ?>" href="<?php echo e(url('/galeri')); ?>">Galeri Kegiatan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link small <?php echo e(request()->is('artikel*') ? 'text-dark fw-bold' : 'text-secondary'); ?>" href="<?php echo e(url('/artikel')); ?>">Artikel</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link small <?php echo e(request()->is('kontak*') ? 'text-dark fw-bold' : 'text-secondary'); ?>" href="<?php echo e(url('/kontak')); ?>">Kontak Kami</a>
                </li>
            </ul>
        </div>

    </div>
</nav><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/partials/navbar-front.blade.php ENDPATH**/ ?>