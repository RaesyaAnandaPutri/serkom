

<?php $__env->startSection('title', 'Manajemen Artikel'); ?>
<?php $__env->startSection('subtitle', 'Kelola semua data artikel atau berita yang ditampilkan di website'); ?>

<?php $__env->startSection('action'); ?>
    <a href="<?php echo e(route('admin.artikel.create')); ?>" class="btn btn-dark rounded-pill px-4 shadow-sm">
        <i class="bi bi-plus-circle-fill me-1"></i> Tambah Artikel
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm rounded-4 p-4">

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr class="text-secondary small text-uppercase">
                    <th>Foto</th>
                    <th>Judul Artikel</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Konten</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="rounded-3 overflow-hidden bg-light border d-flex align-items-center justify-content-center" style="width: 72px; height: 48px;">
                                <?php if($article->gambar): ?>
                                    <img src="<?php echo e(asset('storage/' . $article->gambar)); ?>" alt="<?php echo e($article->judul); ?>" class="w-100 h-100 object-fit-cover">
                                <?php else: ?>
                                    <small class="text-muted">No Img</small>
                                <?php endif; ?>
                            </div>
                        </td>

                        <td class="fw-bold"><?php echo e($article->judul); ?></td>

                        <td class="text-secondary small">
                            <i class="bi bi-calendar3 me-1"></i><?php echo e($article->created_at->translatedFormat('d M Y')); ?>

                        </td>

                        <td>
                            <?php if($article->status == 'publik'): ?>
                                <span class="badge bg-success">Publik</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Draft</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <p class="text-muted small mb-0" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                <?php echo e($article->konten); ?>

                            </p>
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex gap-1">
                                <a href="<?php echo e(route('admin.artikel.edit', $article->id)); ?>" class="btn btn-sm btn-light border text-primary" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('admin.artikel.destroy', $article->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus artikel ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-light border text-danger" title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5">
                            <i class="bi bi-inbox fs-1 text-secondary opacity-50"></i>
                            <h6 class="fw-bold mt-2">Belum Ada Data Artikel</h6>
                            <p class="text-muted small">Silakan tambahkan artikel baru agar muncul di tabel ini.</p>
                            <a href="<?php echo e(route('admin.artikel.create')); ?>" class="btn btn-sm btn-outline-dark rounded-pill px-3">
                                <i class="bi bi-plus-lg me-1"></i> Tambah Artikel Pertama
                            </a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($articles->hasPages()): ?>
        <div class="d-flex justify-content-between align-items-center border-top pt-4 mt-3">
            <small class="text-muted">
                Menampilkan <?php echo e($articles->firstItem()); ?> - <?php echo e($articles->lastItem()); ?> dari <?php echo e($articles->total()); ?> data
            </small>
            <?php echo e($articles->links()); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/admin/articles/index.blade.php ENDPATH**/ ?>