<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($profil->name ?? 'PT Solusi Koneksi Anda'); ?> - IT Solution & Web Development</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #fafafa; }
        .grad { background: linear-gradient(160deg, #2f7df6 0%, #6ab0ff 55%, #c3e1ff 100%); }
        .hero-title { letter-spacing: -1px; }
        .hero-visual { min-height: 500px; border-radius: 28px; }
    </style>
</head>
<body x-data="{ selectedGallery: null }" @keydown.escape.window="selectedGallery = null">

    <?php echo $__env->make('partials.navbar-front', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <section class="hero d-flex align-items-center py-5">
        <div class="container">
            <div class="row g-5 align-items-stretch">
                <div class="col-lg-6 d-flex flex-column justify-content-center">
                    <h1 class="hero-title display-5 fw-bold lh-sm text-dark mb-4">
                        Solusi IT & Web Development untuk Bisnis Anda
                    </h1>
                    <p class="text-secondary mb-4" style="max-width: 480px;">
                        <?php echo e(Str::limit($profil->deskripsi ?? 'Kami membantu perusahaan membangun sistem informasi dan website yang cepat, aman, dan mudah dikembangkan.', 150)); ?>

                    </p>
                    <div class="d-flex flex-wrap align-items-center gap-3">
                        <a href="<?php echo e(url('/profil-perusahaan')); ?>" class="btn bg-dark text-white rounded-pill px-4 py-3 fw-semibold">Baca Selengkapnya</a>
                        <a href="<?php echo e(url('/layanan')); ?>" class="text-dark fw-semibold text-decoration-none">Lihat Layanan</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="hero-visual position-relative h-100 overflow-hidden"
                         style="background-image: url('<?php echo e(asset('images/hero.png')); ?>'), linear-gradient(160deg, #2f7df6, #c3e1ff); background-size: cover; background-position: center;">
                        <div class="position-absolute top-0 start-0 m-4 bg-dark text-white rounded-pill px-3 py-2 small fw-semibold">
                            <i class="bi bi-code-slash me-1"></i> Web Development
                        </div>
                        <div class="position-absolute bottom-0 start-0 m-4 bg-white rounded-pill shadow d-flex align-items-center gap-2 py-2 pe-4 ps-2">
                            <span class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                <i class="bi bi-check-lg"></i>
                            </span>
                            <span class="small fw-semibold text-dark">Siap mendukung<br>transformasi digital</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-5">
        <div class="container py-4">
            <div class="row g-4 align-items-center">
                <div class="col-lg-4 d-flex flex-column gap-4">
                    <div class="d-flex gap-3">
                        <div class="bg-dark text-white rounded-4 d-flex align-items-center justify-content-center flex-shrink-0" style="width: 52px; height: 52px;">
                            <i class="bi bi-people fs-4"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark">Tim Berpengalaman</h5>
                            <p class="small text-secondary mb-0">Developer dan konsultan kami sudah menangani berbagai proyek website dan sistem informasi.</p>
                        </div>
                    </div>
                    <div class="d-flex gap-3">
                        <div class="bg-dark text-white rounded-4 d-flex align-items-center justify-content-center flex-shrink-0" style="width: 52px; height: 52px;">
                            <i class="bi bi-bullseye fs-4"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark">Sesuai Kebutuhan</h5>
                            <p class="small text-secondary mb-0">Setiap proyek dirancang dari kebutuhan bisnis Anda, bukan template yang sama untuk semua klien.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center py-4">
                        <h2 class="hero-title display-4 fw-bold text-dark mb-3">Why choose us?</h2>
                        <p class="text-secondary mb-0">Alasan bisnis Anda layak bermitra dengan kami.</p>
                    </div>
                </div>
                <div class="col-lg-4 d-flex flex-column gap-4">
                    <div class="d-flex gap-3">
                        <div class="bg-dark text-white rounded-4 d-flex align-items-center justify-content-center flex-shrink-0" style="width: 52px; height: 52px;">
                            <i class="bi bi-shield-check fs-4"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark">Aman & Andal</h5>
                            <p class="small text-secondary mb-0">Sistem dibangun dengan standar keamanan yang baik dan diuji dulu sebelum diserahkan.</p>
                        </div>
                    </div>
                    <div class="d-flex gap-3">
                        <div class="bg-dark text-white rounded-4 d-flex align-items-center justify-content-center flex-shrink-0" style="width: 52px; height: 52px;">
                            <i class="bi bi-headset fs-4"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark">Dukungan Berkelanjutan</h5>
                            <p class="small text-secondary mb-0">Kami tetap mendampingi dan merawat sistem setelah berjalan, bukan berhenti saat proyek selesai.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-5">
        <div class="container py-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-5">
                <div style="max-width: 520px;">
                    <h2 class="hero-title fw-bold text-dark mb-2">Layanan IT untuk mengembangkan bisnis Anda</h2>
                    <p class="text-secondary mb-0">Dari pembuatan website sampai konsultasi sistem informasi.</p>
                </div>
                <a href="<?php echo e(url('/layanan')); ?>" class="btn btn-outline-dark rounded-pill px-4">Lihat Semua</a>
            </div>

            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $layanan->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    
                    <a href="<?php echo e(route('layanan.show', $item->id)); ?>" class="card h-100 border rounded-4 p-2 text-decoration-none text-dark shadow-sm d-block transition-card">
                        
                        
                        <?php if($item->gambar): ?>
                            <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" class="rounded-4 w-100" style="height: 200px; object-fit: cover;" alt="<?php echo e($item->nama); ?>">
                        <?php else: ?>
                            <div class="grad rounded-4 text-white d-flex align-items-center justify-content-center" style="height: 200px;">
                                <i class="bi bi-laptop fs-1"></i>
                            </div>
                        <?php endif; ?>

                        <div class="p-3">
                            <h5 class="fw-bold text-dark mb-2"><?php echo e($item->nama); ?></h5>
                            <p class="small text-secondary mb-3"><?php echo e(Str::limit(strip_tags($item->deskripsi), 90)); ?></p>
                            <span class="small fw-semibold text-dark">Baca selengkapnya &rsaquo;</span>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <p class="text-secondary">Belum ada layanan.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>


    <section class="py-5 bg-white border-top">
        <div class="container py-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-5">
                <h2 class="hero-title fw-bold text-dark mb-0">Galeri kegiatan & proyek</h2>
                <a href="<?php echo e(url('/galeri')); ?>" class="btn btn-outline-dark rounded-pill px-4">Lihat Semua</a>
            </div>

            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $galeri->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <div class="card h-100 border rounded-4 p-2 shadow-sm"
                         role="button"
                         tabindex="0"
                         aria-label="Lihat detail <?php echo e($gal->judul ?? $gal->title); ?>"
                         style="cursor: pointer;"
                         @click="selectedGallery = {
                            title: <?php echo \Illuminate\Support\Js::from($gal->judul ?? $gal->title)->toHtml() ?>,
                            description: <?php echo \Illuminate\Support\Js::from(strip_tags($gal->deskripsi ?? $gal->description ?? 'Tidak ada deskripsi.'))->toHtml() ?>,
                            image: <?php echo \Illuminate\Support\Js::from(($gal->gambar ?? $gal->image) ? asset('storage/' . ($gal->gambar ?? $gal->image)) : null)->toHtml() ?>,
                            date: <?php echo \Illuminate\Support\Js::from($gal->created_at->translatedFormat('d M Y'))->toHtml() ?>
                         }"
                         @keydown.enter.prevent="$el.click()"
                         @keydown.space.prevent="$el.click()">
                        <?php if($gal->gambar ?? $gal->image): ?>
                            <img src="<?php echo e(asset('storage/' . ($gal->gambar ?? $gal->image))); ?>" class="rounded-4 w-100" style="height: 220px; object-fit: cover;" alt="<?php echo e($gal->judul ?? $gal->title); ?>">
                        <?php else: ?>
                            <div class="grad rounded-4 text-white d-flex align-items-center justify-content-center" style="height: 220px;">
                                <i class="bi bi-image fs-1"></i>
                            </div>
                        <?php endif; ?>
                        <div class="p-3">
                            
                            <span class="badge bg-light border text-secondary rounded-pill mb-2">
                                <i class="bi bi-calendar3 me-1"></i> <?php echo e($gal->created_at->translatedFormat('d M Y')); ?>

                            </span>

                            <h6 class="fw-bold text-dark mb-0"><?php echo e($gal->judul ?? $gal->title); ?></h6>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <p class="text-secondary mb-0">Belum ada foto galeri.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <template x-if="selectedGallery">
        <div x-transition.opacity
             class="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center p-3"
             style="z-index: 1080; background: rgba(15, 23, 42, .6);"
             role="presentation"
             @click.self="selectedGallery = null">
            <section x-transition
                     role="dialog"
                     aria-modal="true"
                     aria-labelledby="home-gallery-detail-title"
                     class="card border-0 rounded-4 shadow-lg overflow-hidden w-100"
                     style="max-width: 760px; max-height: 90vh;">
                <div class="row g-0">
                    <div class="col-md-6 bg-light d-flex align-items-center justify-content-center" style="min-height: 240px;">
                        <template x-if="selectedGallery.image">
                            <img :src="selectedGallery.image"
                                 :alt="selectedGallery.title"
                                 class="w-100 h-100 object-fit-cover"
                                 style="min-height: 240px; max-height: 520px;">
                        </template>
                        <template x-if="!selectedGallery.image">
                            <div class="grad w-100 h-100 text-white d-flex align-items-center justify-content-center" style="min-height: 240px;">
                                <i class="bi bi-image fs-1"></i>
                            </div>
                        </template>
                    </div>
                    <div class="col-md-6 d-flex flex-column overflow-auto">
                        <div class="p-4 p-lg-5">
                            <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
                                <span class="badge bg-light border text-secondary rounded-pill">
                                    <i class="bi bi-calendar3 me-1"></i>
                                    <span x-text="selectedGallery.date"></span>
                                </span>
                                <button type="button"
                                        class="btn-close"
                                        aria-label="Tutup detail galeri"
                                        @click="selectedGallery = null"></button>
                            </div>
                            <h2 id="home-gallery-detail-title" class="h4 fw-bold text-dark mb-3" x-text="selectedGallery.title"></h2>
                            <p class="text-secondary mb-0" style="white-space: pre-line;" x-text="selectedGallery.description"></p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </template>


    <section class="py-5 border-top">
        <div class="container py-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-5">
                <h2 class="hero-title fw-bold text-dark mb-0">Artikel & informasi terkini</h2>
                <a href="<?php echo e(url('/artikel')); ?>" class="btn btn-outline-dark rounded-pill px-4">Lihat Semua</a>
            </div>

            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $artikel->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <div class="card h-100 border rounded-4 p-2">
                        <?php if($art->gambar): ?>
                            <img src="<?php echo e(asset('storage/' . $art->gambar)); ?>" class="rounded-4 w-100" style="height: 200px; object-fit: cover;" alt="<?php echo e($art->judul); ?>">
                        <?php else: ?>
                            <div class="grad rounded-4 text-white d-flex align-items-center justify-content-center" style="height: 200px;">
                                <i class="bi bi-newspaper fs-1"></i>
                            </div>
                        <?php endif; ?>
                        <div class="p-3">
                            <span class="badge bg-light border text-secondary rounded-pill mb-2">
                                <i class="bi bi-calendar3 me-1"></i> <?php echo e($art->created_at->format('d M Y')); ?>

                            </span>
                            <h5 class="fw-bold text-dark"><?php echo e($art->judul); ?></h5>
                            <p class="small text-secondary mb-3"><?php echo e(Str::limit(strip_tags($art->konten), 90)); ?></p>
                            
                            
                            <a href="<?php echo e(route('artikel.show', $art->id)); ?>" class="text-dark fw-semibold small text-decoration-none">
                                Baca Selengkapnya <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-secondary">Belum ada artikel.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php echo $__env->make('partials.footer-front', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.17.4/dist/cdn.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/frontend/home.blade.php ENDPATH**/ ?>