<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kontak & Penilaian - PT Solusi Koneksi Anda</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #fafafa; }
        .rating-stars {
            display: flex;
            flex-direction: row-reverse;
            justify-content: flex-end;
            gap: 8px;
        }
        .rating-stars input { display: none; }
        .rating-stars label {
            font-size: 1.8rem;
            color: #ccc;
            cursor: pointer;
            transition: color 0.2s;
        }
        .rating-stars input:checked ~ label,
        .rating-stars label:hover,
        .rating-stars label:hover ~ label {
            color: #ffc107;
        }
    </style>
</head>
<body>

    <?php echo $__env->make('partials.navbar-front', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <section class="py-5">
        <div class="container py-4 text-center" style="max-width: 700px;">
            <h1 class="display-5 fw-bold text-dark mb-3">Kirim Pesan & Penilaian</h1>
            <p class="text-secondary mb-0">
                Bagikan tanggapan, pesan, atau ulasan Anda mengenai layanan kami.
            </p>
        </div>
    </section>

    
    <section class="pb-5">
        <div class="container pb-4" style="max-width: 650px;">
            <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5 bg-white">
                
                
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show rounded-3 mb-4" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i> <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('front.kontak.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small text-dark">Nama Anda <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control rounded-3 <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nama')); ?>" placeholder="Masukkan nama Anda" required>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-4">
                    <label class="form-label fw-semibold small text-dark">Email Anda <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control rounded-3 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" placeholder="nama@email.com" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                    
                    <div class="mb-4">
                        <label class="form-label fw-semibold small text-dark d-block">Beri Penilaian (Rating)</label>
                        <div class="rating-stars">
                            <input type="radio" id="star5" name="rating" value="5" <?php echo e(old('rating') == '5' ? 'checked' : ''); ?> />
                            <label for="star5" title="Sangat Bagus"><i class="bi bi-star-fill"></i></label>

                            <input type="radio" id="star4" name="rating" value="4" <?php echo e(old('rating') == '4' ? 'checked' : ''); ?> />
                            <label for="star4" title="Bagus"><i class="bi bi-star-fill"></i></label>

                            <input type="radio" id="star3" name="rating" value="3" <?php echo e(old('rating') == '3' ? 'checked' : ''); ?> />
                            <label for="star3" title="Cukup"><i class="bi bi-star-fill"></i></label>

                            <input type="radio" id="star2" name="rating" value="2" <?php echo e(old('rating') == '2' ? 'checked' : ''); ?> />
                            <label for="star2" title="Buruk"><i class="bi bi-star-fill"></i></label>

                            <input type="radio" id="star1" name="rating" value="1" <?php echo e(old('rating') == '1' ? 'checked' : ''); ?> />
                            <label for="star1" title="Sangat Buruk"><i class="bi bi-star-fill"></i></label>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small text-dark">Pesan / Masukan <span class="text-danger">*</span></label>
                        <textarea name="pesan" rows="5" class="form-control rounded-3 <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Tuliskan pesan Anda di sini..." required><?php echo e(old('pesan')); ?></textarea>
                        <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-dark rounded-pill px-4 py-2 fw-semibold shadow-sm w-100">
                        <i class="bi bi-send me-1"></i> Kirim Pesan & Penilaian
                    </button>
                </form>
            </div>
        </div>
    </section>

    <?php echo $__env->make('partials.footer-front', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/frontend/kontak.blade.php ENDPATH**/ ?>