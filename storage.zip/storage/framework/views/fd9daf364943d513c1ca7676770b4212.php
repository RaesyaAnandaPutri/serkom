<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> - Solusi Koneksi Anda</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root { --bs-primary: #64748b; --bs-primary-rgb: 100, 116, 139; --bs-body-font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background: linear-gradient(160deg, #f1f3f5, #e9ecef); font-size: .88rem; }
        .app { max-width: 1600px; }
        .app-card { min-height: calc(100vh - 2rem); }
        .nav-pills { --bs-nav-pills-link-active-bg: #64748b; }
        .avatar { width: 52px; height: 52px; }
    </style>
</head>
<body class="min-vh-100 p-2 p-md-3">
    <div class="app w-100 mx-auto">
        <div class="app-card row g-0 bg-white rounded-5 overflow-hidden shadow border">

            <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="col-12 col-lg-9 bg-light p-4 d-flex flex-column">
                
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
                    <div>
                        <h4 class="fw-bold mb-0"><?php echo $__env->yieldContent('title'); ?></h4>
                        <small class="text-muted"><?php echo $__env->yieldContent('subtitle', 'Kelola data website dengan mudah dan cepat.'); ?></small>
                    </div>
                    <?php echo $__env->yieldContent('action'); ?>
                </div>

                
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show border-0 rounded-4" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>

                <p class="text-center text-muted small border-top pt-3 mt-auto mb-0">&copy; <?php echo e(date('Y')); ?> PT Solusi Koneksi Anda</p>
            </main>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/layouts/admin.blade.php ENDPATH**/ ?>