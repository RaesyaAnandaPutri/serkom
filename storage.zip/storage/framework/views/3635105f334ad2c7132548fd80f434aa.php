

<?php $__env->startSection('title', 'Edit Layanan'); ?>
<?php $__env->startSection('subtitle', 'Perbarui informasi data layanan atau produk perusahaan.'); ?>

<?php $__env->startSection('action'); ?>
    <a href="<?php echo e(route('admin.layanan.index')); ?>" class="btn btn-outline-dark btn-sm rounded-pill px-3">
        <i class="bi bi-arrow-left me-1"></i> Kembali ke layanan
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-4 p-lg-5">

        <form action="<?php echo e(route('admin.layanan.update', $service->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row g-4">

                
                <div class="col-lg-7">
                    <label class="form-label fw-semibold small">Ganti Foto (Opsional)</label>

                    <div class="border border-2 rounded-4 p-4 text-center position-relative overflow-hidden bg-light d-flex flex-column justify-content-center align-items-center mb-1"
                         style="min-height: 180px; cursor: pointer;"
                         onclick="document.getElementById('imageInput').click()">

                        <div id="placeholder">
                            <i class="bi bi-cloud-arrow-up fs-3 text-primary"></i>
                            <div class="fw-medium small">Klik untuk mengganti foto</div>
                            <small class="text-muted">Format: JPG, PNG, WEBP (Maks. 2MB)</small>
                        </div>

                        <div id="preview-box" class="position-absolute top-0 start-0 w-100 h-100 bg-white p-2 align-items-center justify-content-center" style="display: none;">
                            <img id="preview-img" src="" alt="Pratinjau" class="rounded-3 shadow-sm" style="max-height: 160px; max-width: 100%;">
                        </div>

                        <input type="file" name="gambar" id="imageInput" class="d-none" accept="image/*" onchange="tampilkanPratinjau(this)">
                    </div>
                    <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    
                    <?php if($service->gambar): ?>
                        <label class="form-label fw-semibold small d-block mt-3">Foto Saat Ini:</label>
                        <div class="rounded-3 overflow-hidden border bg-light shadow-sm" style="width: 140px; height: 90px;">
                            <img src="<?php echo e(asset('storage/' . $service->gambar)); ?>" alt="<?php echo e($service->nama); ?>" class="w-100 h-100 object-fit-cover">
                        </div>
                    <?php endif; ?>

                    <label class="form-label fw-semibold small mt-3">Deskripsi Layanan <span class="text-danger">*</span></label>
                    <textarea name="deskripsi" rows="5" class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo e(old('deskripsi', $service->deskripsi)); ?></textarea>
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="col-lg-5">
                    <label class="form-label fw-semibold small">Kategori Layanan <span class="text-danger">*</span></label>
                    <select name="kategori" class="form-select <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="" disabled>Pilih Kategori Layanan</option>
                        <option value="Web Development" <?php echo e(old('kategori', $service->kategori) == 'Web Development' ? 'selected' : ''); ?>>Web Development</option>
                        <option value="Mobile Apps" <?php echo e(old('kategori', $service->kategori) == 'Mobile Apps' ? 'selected' : ''); ?>>Mobile Apps</option>
                        <option value="Sistem Informasi" <?php echo e(old('kategori', $service->kategori) == 'Sistem Informasi' ? 'selected' : ''); ?>>Sistem Informasi</option>
                        <option value="IT Consulting & Cloud" <?php echo e(old('kategori', $service->kategori) == 'IT Consulting & Cloud' ? 'selected' : ''); ?>>IT Consulting & Cloud</option>
                    </select>
                    <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label class="form-label fw-semibold small mt-4">Nama Layanan <span class="text-danger">*</span></label>
                    <input type="text" name="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nama', $service->nama)); ?>" required>
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label class="form-label fw-semibold small mt-4">Tanggal</label>
                    <input type="date" name="date" class="form-control" value="<?php echo e(old('date', $service->created_at->format('Y-m-d'))); ?>" required>

                    <label class="form-label fw-semibold small mt-4">Status</label>
                    <select name="status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="draft" <?php echo e(old('status', $service->status) == 'draft' ? 'selected' : ''); ?>>Draft (belum tampil di website)</option>
                        <option value="publik" <?php echo e(old('status', $service->status) == 'publik' ? 'selected' : ''); ?>>Publik (tampil di website)</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="col-12 border-top pt-4 d-flex justify-content-end gap-2">
                    <a href="<?php echo e(route('admin.layanan.index')); ?>" class="btn btn-outline-secondary rounded-pill px-4">Batal</a>
                    <button type="submit" class="btn btn-dark rounded-pill px-4 shadow-sm">Simpan Perubahan</button>
                </div>

            </div>
        </form>

    </div>
</div>

<script>
    function tampilkanPratinjau(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById('preview-img').src = e.target.result;
                document.getElementById('placeholder').style.display = 'none';
                document.getElementById('preview-box').style.display = 'flex';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>