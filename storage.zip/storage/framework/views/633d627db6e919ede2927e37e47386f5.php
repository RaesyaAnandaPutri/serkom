<?php $p = $profil ?? \App\Models\CompanyProfile::first(); ?>

<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row g-4">

            <div class="col-md-3">
                <h5 class="fw-bold"><?php echo e($p->name ?? 'Solusi Koneksi Anda'); ?></h5>
                <p class="small text-white-50 mb-0">IT Solution & Web Development</p>
            </div>

            <div class="col-md-3">
                <h6 class="fw-bold mb-3">Menu</h6>
                <ul class="list-unstyled small mb-0">
                    <li class="mb-2"><a href="<?php echo e(url('/')); ?>" class="text-white-50 text-decoration-none">Home</a></li>
                    <li class="mb-2"><a href="<?php echo e(url('/profil-perusahaan')); ?>" class="text-white-50 text-decoration-none">Profil Perusahaan</a></li>
                    <li class="mb-2"><a href="<?php echo e(url('/layanan')); ?>" class="text-white-50 text-decoration-none">Produk & Layanan</a></li>
                    <li class="mb-2"><a href="<?php echo e(url('/artikel')); ?>" class="text-white-50 text-decoration-none">Artikel</a></li>
                    <li class="mb-2"><a href="<?php echo e(url('/galeri')); ?>" class="text-white-50 text-decoration-none">Galeri Kegiatan</a></li>
                    <li><a href="<?php echo e(url('/kontak')); ?>" class="text-white-50 text-decoration-none">Kontak Kami</a></li>
                </ul>
            </div>

            <div class="col-md-3">
                <h6 class="fw-bold mb-3">Kontak</h6>
                <ul class="list-unstyled small text-white-50 mb-0">
                    <li class="mb-2"><i class="bi bi-geo-alt-fill me-2"></i><?php echo e($p->alamat ?? 'Jl. M.H. Thamrin No. 12, Kebon Sirih, Kec. Menteng, Jakarta Pusat, DKI Jakarta 10340'); ?></li>
                    <li class="mb-2"><i class="bi bi-telephone-fill me-2"></i><?php echo e($p->telepon ?? '(0251) 888-999'); ?></li>
                    <li><i class="bi bi-envelope-fill me-2"></i><?php echo e($p->email ?? 'info@solusikoneksianda.co.id'); ?></li>
                </ul>
            </div>

            <div class="col-md-3">
                <h6 class="fw-bold mb-3">Jam Operasional</h6>
                <ul class="list-unstyled small text-white-50 mb-0">
                    <li class="mb-2">Senin – Jumat: 08.30 – 17.30 WIB</li>
                    <li>Sabtu – Minggu: Tutup (Emergency Support via Email)</li>
                </ul>
            </div>

        </div>

        <hr class="border-secondary my-4">
        <p class="small text-white-50 text-center mb-0">&copy; <?php echo e(date('Y')); ?> <?php echo e($p->name ?? 'PT Solusi Koneksi Anda'); ?>. All rights reserved.</p>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/partials/footer-front.blade.php ENDPATH**/ ?>