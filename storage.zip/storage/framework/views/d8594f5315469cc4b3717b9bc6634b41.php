

<?php $__env->startSection('title', 'Hello, Admin'); ?>
<?php $__env->startSection('subtitle', now()->locale('id')->translatedFormat('l, d F Y')); ?>

<?php $__env->startSection('action'); ?>
    <a href="<?php echo e(url('/')); ?>" target="_blank" class="btn btn-dark btn-sm rounded-pill px-4">Lihat Website</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="row g-3 mb-4">

        
        <div class="col-md-4">
            <a href="<?php echo e(url('/admin/layanan')); ?>" class="d-block text-white text-decoration-none rounded-4 p-4 shadow-sm" style="background-color: #64748b;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge rounded-pill bg-white bg-opacity-25 fw-medium">Layanan</span>
                    <i class="bi bi-box-seam fs-5"></i>
                </div>
                <div class="fs-2 fw-bold lh-1"><?php echo e($jumlahLayanan); ?></div>
                <div class="small mb-2">Total produk / layanan</div>
                <small>Lihat semua &rsaquo;</small>
            </a>
        </div>

        
        <div class="col-md-4">
            <a href="<?php echo e(url('/admin/artikel')); ?>" class="d-block text-white text-decoration-none rounded-4 p-4 shadow-sm" style="background-color: #64748b;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge rounded-pill bg-white bg-opacity-25 fw-medium">Artikel</span>
                    <i class="bi bi-journal-text fs-5"></i>
                </div>
                <div class="fs-2 fw-bold lh-1"><?php echo e($jumlahArtikel); ?></div>
                <div class="small mb-2">Total artikel dipublikasi</div>
                <small>Lihat semua &rsaquo;</small>
            </a>
        </div>

        
        <div class="col-md-4">
            <a href="<?php echo e(url('/admin/galeri')); ?>" class="d-block text-white text-decoration-none rounded-4 p-4 shadow-sm" style="background-color: #64748b;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge rounded-pill bg-white bg-opacity-25 fw-medium">Galeri</span>
                    <i class="bi bi-images fs-5"></i>
                </div>
                <div class="fs-2 fw-bold lh-1"><?php echo e($jumlahGaleri); ?></div>
                <div class="small mb-2">Total foto kegiatan</div>
                <small>Lihat semua &rsaquo;</small>
            </a>
        </div>

    </div>

    
    <div class="row g-3">

        
        <div class="col-lg-4">
            <div class="card rounded-4 h-100 border-0 shadow-sm">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Aksi Cepat</h6>
                    <div class="d-flex flex-column gap-2">

                        <a href="<?php echo e(url('/admin/layanan/create')); ?>" class="d-flex justify-content-between align-items-center bg-light rounded-3 p-3 text-dark text-decoration-none border-start border-4" style="border-color: #64748b !important;">
                            Tambah Layanan <i class="bi bi-plus-lg text-muted"></i>
                        </a>

                        <a href="<?php echo e(url('/admin/artikel/create')); ?>" class="d-flex justify-content-between align-items-center bg-light rounded-3 p-3 text-dark text-decoration-none border-start border-4" style="border-color: #64748b !important;">
                            Tambah Artikel <i class="bi bi-plus-lg text-muted"></i>
                        </a>

                        <a href="<?php echo e(url('/admin/galeri/create')); ?>" class="d-flex justify-content-between align-items-center bg-light rounded-3 p-3 text-dark text-decoration-none border-start border-4" style="border-color: #64748b !important;">
                            Tambah Galeri <i class="bi bi-plus-lg text-muted"></i>
                        </a>

                        <a href="<?php echo e(url('/admin/profil')); ?>" class="d-flex justify-content-between align-items-center bg-light rounded-3 p-3 text-dark text-decoration-none border-start border-4" style="border-color: #cbd5e1 !important;">
                            Edit Profil Perusahaan <small class="text-muted"><?php echo e($profil ? 'Sudah diisi' : 'Belum diisi'); ?></small>
                        </a>

                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-4">
            <div class="card rounded-4 h-100 border-0 shadow-sm">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="fw-bold mb-0">Layanan Terbaru</h6>
                        <a href="<?php echo e(url('/admin/layanan')); ?>" class="small text-primary text-decoration-none">Lihat semua</a>
                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $layananTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex align-items-center justify-content-between gap-2 py-2 border-bottom">
                            <div class="d-flex align-items-center gap-2 flex-grow-1" style="min-width: 0;">
                                
                                <?php if($layanan->gambar): ?>
                                    <img src="<?php echo e(asset('storage/' . $layanan->gambar)); ?>" alt="<?php echo e($layanan->nama ?? $layanan->judul); ?>" class="rounded-3 object-fit-cover flex-shrink-0" style="width: 40px; height: 40px;">
                                <?php else: ?>
                                    <div class="bg-light rounded-3 d-flex align-items-center justify-content-center text-muted flex-shrink-0" style="width: 40px; height: 40px;">
                                        <i class="bi bi-image small"></i>
                                    </div>
                                <?php endif; ?>
                                <span class="text-dark fw-semibold small text-truncate" style="min-width: 0;" title="<?php echo e($layanan->nama ?? $layanan->judul); ?>"><?php echo e($layanan->nama ?? $layanan->judul); ?></span>
                            </div>
                            <small class="text-muted text-nowrap flex-shrink-0" style="font-size: 0.75rem;"><?php echo e($layanan->created_at->translatedFormat('d M Y')); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted text-center py-3 mb-0 small">Belum ada layanan.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4">
            <div class="card rounded-4 h-100 border-0 shadow-sm">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="fw-bold mb-0">Artikel Terbaru</h6>
                        <a href="<?php echo e(url('/admin/artikel')); ?>" class="small text-primary text-decoration-none">Lihat semua</a>
                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $artikelTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex align-items-center justify-content-between gap-2 py-2 border-bottom">
                            <div class="d-flex align-items-center gap-2 flex-grow-1" style="min-width: 0;">
                                
                                <?php if($artikel->gambar): ?>
                                    <img src="<?php echo e(asset('storage/' . $artikel->gambar)); ?>" alt="<?php echo e($artikel->judul); ?>" class="rounded-3 object-fit-cover flex-shrink-0" style="width: 40px; height: 40px;">
                                <?php else: ?>
                                    <div class="bg-light rounded-3 d-flex align-items-center justify-content-center text-muted flex-shrink-0" style="width: 40px; height: 40px;">
                                        <i class="bi bi-image small"></i>
                                    </div>
                                <?php endif; ?>
                                <span class="text-dark fw-semibold small text-truncate" style="min-width: 0;" title="<?php echo e($artikel->judul); ?>"><?php echo e($artikel->judul); ?></span>
                            </div>
                            <small class="text-muted text-nowrap flex-shrink-0" style="font-size: 0.75rem;"><?php echo e($artikel->created_at->translatedFormat('d M Y')); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted text-center py-3 mb-0 small">Belum ada artikel.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\solusi-koneksi-anda\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>